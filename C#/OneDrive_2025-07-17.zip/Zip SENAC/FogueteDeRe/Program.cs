﻿
using FogueteDeRe.Foguete;


const string MENU = "Menu de Opções:\n" +
    "1. Cadastrar Ex-Terraplanista \n" +
    "2. Descrever missão\n" +
    "3. Sair";


int opcao;

    Console.WriteLine(MENU);
    Console.Write("Escolha uma opção: ");
    opcao = int.Parse(Console.ReadLine());
do
{

    switch (opcao)
    {
        case 1:
            Astronauta.CadastrarAstronauta();
            break;
        case 2:
            Astronauta.RealizarLancamento();
            break;
        case 3:
            Console.WriteLine("Saindo...");
            break;
        default:
            Console.WriteLine("Opção inválida. Tente novamente.");
            break;
    }
    Console.WriteLine(MENU);
    Console.Write("Escolha uma opção: ");
    opcao = int.Parse(Console.ReadLine());

} while (opcao != 3);









//static void Main()
//{
//    int opcao;

//    do
//    {
//        Console.WriteLine("\n===== Menu Espacial =====");
//        Console.WriteLine("1 - Cadastrar Ex-Terraplanista");
//        Console.WriteLine("5 - Sair");
//        Console.Write("Escolha uma opção: ");

//        while (!int.TryParse(Console.ReadLine(), out opcao))
//        {
//            Console.Write("Entrada inválida. Digite um número entre 1 e 5: ");
//        }

//        switch (opcao)
//        {
//            case 1:
//                CadastrarAstronauta();
//                break;
//            default:
//                Console.WriteLine("Opção inválida. Tente novamente.");
//                break;
//        }

//    } while (opcao != 5);
//}

//foreach (var astronauta in astronautas)
//{
//    Console.WriteLine(nome, datanascimento, pais);

//}


////Nasa.Exterraplanista()
