﻿namespace PetShoes.Model.Adotantes
{
    public class AdotanteResponseModel
    {
        public Guid Id { get; set; }
        public string IdAnimal { get; set; }
        public string NomeAnimal { get; set; }
        public string Nome { get; set; }
        public string DataNascimento { get; set; }
        public int CPF { get; set; }
    }
}
